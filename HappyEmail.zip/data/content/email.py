#Values change email formatting properties

#Number of images and quotes per email
NUMBER_OF_RESULTS = 3

#Font size for body of email
EMAIL_FONT_SIZE = 72

#Max length allowed for scraped quotes in characters
#  if greater than max, will scrape again.
MAX_QUOTE_SIZE = 300

#Header for email
