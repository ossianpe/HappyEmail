#Google Developer Search Key
#Generated at pass
#Custom Search Engine ID
GCSEARCH_DEV_KEY = "AIzaSyBTifkdNboeglu-ZeWR6Zkw8rXSfty2png"
GCSEARCH_CX = "005028350008021655403:vbn4syiduio"

#Credentials for sending Gmail
GMAIL_SENDER_USERNAME = 'drcampydaghara@gmail.com'
GMAIL_SENDER_PASSWORD = 'nad48ara'

EMAIL_ADDRESS_DB_LOCATION = "storage/database/"
EMAIL_ADDRESS_DB_FILENAME = "email_addresses.db"
EMAIL_ADDRESS_DB = EMAIL_ADDRESS_DB_LOCATION + EMAIL_ADDRESS_DB_FILENAME
EMAIL_ADDRESS_CONTACTS_TABLE = 'People'

#Add email addresses to list if no email_addresses database present.
ALL_RECIPIENTS = ["cephasara@gmail.com"]